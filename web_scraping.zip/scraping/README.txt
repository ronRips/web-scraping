name: aharon rips
ID: 021930136

I developed this program in java with IntelliJ
To execute the code you need to run it
Insert the input by the command line
The output will be displayed at the file - "list_of_movies.txt"

Thank you